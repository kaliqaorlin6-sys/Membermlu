document.getElementById('search').addEventListener('keyup', function(){
let value=this.value.toLowerCase();
document.querySelectorAll('.member').forEach(function(item){
item.style.display=item.innerText.toLowerCase().includes(value)?'block':'none';
});
});